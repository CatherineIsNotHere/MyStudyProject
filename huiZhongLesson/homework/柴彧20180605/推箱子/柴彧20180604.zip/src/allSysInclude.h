#pragma once
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
using namespace std;