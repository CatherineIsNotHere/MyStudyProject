#pragma once

extern enum gameOption {
	YSize = 23,
	XSize = 36,
	wordSpeedDown = 1000,
	wordSpeedUp = 1000
};

extern enum wordExits {
	notExist = 0,
	engExist = 1,
	cnExist = 2,
	overExist = 3
};