#pragma once
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <thread>
using namespace std;