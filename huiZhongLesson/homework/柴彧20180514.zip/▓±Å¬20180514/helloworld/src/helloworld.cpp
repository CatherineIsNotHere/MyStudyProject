#include <iostream>
#include <stdlib.h>
using namespace std;

void main(){
	cout << "helloworld!" << endl;

	system("pause");
}